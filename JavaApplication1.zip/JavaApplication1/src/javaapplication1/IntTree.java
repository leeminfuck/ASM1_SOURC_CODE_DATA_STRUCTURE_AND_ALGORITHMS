/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author Lee Min Cun
 */
class IntTree {
    
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("1", "Alice", 8.5));
        students.add(new Student("2", "Bob", 7.0));
        students.add(new Student("3", "Charlie", 5.5));
        students.add(new Student("4", "David", 7.0));
        students.add(new Student("5", "Davine", 7.0));
        // TimSort Example
        List<Student> timSortStudents = new ArrayList<>(students);
        timSortStudents.sort(Comparator.comparing(Student::getMarks).reversed());
        System.out.println("TimSort Result:");
        timSortStudents.forEach(System.out::println);

        // QuickSort Example
        List<Student> quickSortStudents = new ArrayList<>(students);
        quickSort(quickSortStudents, 0, quickSortStudents.size() - 1);
        System.out.println("QuickSort Result:");
        quickSortStudents.forEach(System.out::println);
    }

    public static void quickSort(List<Student> list, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(list, low, high);
            quickSort(list, low, pivotIndex - 1);
            quickSort(list, pivotIndex + 1, high);
        }
    }

    public static int partition(List<Student> list, int low, int high) {
        double pivot = list.get(high).getMarks();
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (list.get(j).getMarks() >= pivot) {
                i++;
                Collections.swap(list, i, j);
            }
        }
        Collections.swap(list, i + 1, high);
        return i + 1;
    }
}

class Student {
    private String id;
    private String name;
    private double marks;

    public Student(String id, String name, double marks) {
        this.id = id;
        this.name = name;
        this.marks = marks;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getMarks() {
        return marks;
    }

    @Override
    public String toString() {
        return "Student ID: " + id + ", Name: " + name + ", Marks: " + marks;
    }
}

