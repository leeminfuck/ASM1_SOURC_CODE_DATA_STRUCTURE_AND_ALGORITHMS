/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ASM1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Comparator;
/**
 *
 * @author Lee Min Cun
 */
public class StudentInformationSystem{
    private final List<Student> students;
    private final Scanner scanner;
    public StudentInformationSystem(){
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    public void addStudent(){
        System.out.println("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.println("Enter student Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter student Marks: ");
        float mark = scanner.nextFloat();
       
        scanner.nextLine();
        System.out.print("Enter Student Phone Number: ");
        String phoneNumber = scanner.nextLine();
        Student student = new Student(id, name, mark);
        students.add(new Student(id, name, mark));
        student.updatePhoneNumber(phoneNumber);
        
        System.out.println("Student added successfully.");   
    }
    public void editStudent(){
        System.out.println("Enter student ID to edit: ");
        String id = scanner.nextLine();
        for (Student student : students){
            if (student.getID().equals(id)){
                System.out.println("Enter new name: ");
                String name = scanner.nextLine();
                System.out.println("Enter new marks: ");
                float mark = scanner.nextFloat();
                scanner.nextLine();
                
                student.setName(name);
                student.setMark(mark);
                System.out.println("Student updated successfully");
                return;
            }
        }
    }
    public void sortStudent(){
        students.sort(Comparator.comparing(Student::getMark).reversed());
        System.out.println("Students sorted by marks in descending order");   
    }
//        public void sortStudent() {
//        quickSort(0, students.size() - 1);
//        System.out.println("Students sorted by marks in descending order.");
//    }
//
//    private void quickSort(int low, int high) {
//        if (low < high) {
//            int pi = partition(low, high);
//            quickSort(low, pi - 1);
//            quickSort(pi + 1, high);
//        }
//    }
//
//    private int partition(int low, int high) {
//        double pivot = students.get(high).getMark();
//        int i = low - 1;
//        for (int j = low; j < high; j++) {
//            if (students.get(j).getMark() >= pivot) {
//                i++;
//                swap(i, j);
//            }
//        }
//        swap(i + 1, high);
//        return i + 1;
//    }
//
//    private void swap(int i, int j) {
//        Student temp = students.get(i);
//        students.set(i, students.get(j));
//        students.set(j, temp);
//    }

    public void searchStudentById() {
        System.out.print("Enter Student ID to search: ");
        String id = scanner.nextLine();
        for (Student student : students) {
            if (student.getID().equals(id)) {
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student not found.");
    }
    public void delStudent(){
        System.out.println("Enter Student ID to delete: ");
        String id = scanner.nextLine();
        students.removeIf(student -> student.getID().equals(id));
        System.out.println("Student deleted successfully");
    }
    public void searchStudentByID(){
        System.out.println("Enter Student ID to search: ");
        String id = scanner.nextLine();
        for (Student student : students){
            if (student.getID().equals(id)){
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student not found");
    }
    public void displayAllStudents(){
    if (students.isEmpty()){
        System.out.println("No Students to display");
    } else{
        for (Student student : students){
            System.out.println(student);
        }
    }
    }
    
}
